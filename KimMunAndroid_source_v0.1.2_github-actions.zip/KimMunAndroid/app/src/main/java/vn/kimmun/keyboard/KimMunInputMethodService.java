package vn.kimmun.keyboard;

import android.inputmethodservice.InputMethodService;
import android.view.View;
import android.view.ViewGroup;
import android.view.Gravity;
import android.view.inputmethod.InputConnection;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;

public class KimMunInputMethodService extends InputMethodService {
    private LinearLayout keyboard;
    private final StringBuilder composing = new StringBuilder();
    private boolean shifted = false;

    @Override public View onCreateInputView() {
        keyboard = new LinearLayout(this);
        keyboard.setOrientation(LinearLayout.VERTICAL);
        keyboard.setPadding(dp(3), dp(5), dp(3), dp(5));
        keyboard.setBackgroundColor(Color.rgb(224,231,240));
        addRow(new String[]{"q","w","e","r","t","y","u","i","o","p"});
        addRow(new String[]{"a","s","d","f","g","h","j","k","l"});
        addRow(new String[]{"⇧","z","x","c","v","b","n","m","⌫"});
        addRow(new String[]{"?123",",","th","tk","PY","␠",".","↵"});
        return keyboard;
    }

    private void addRow(String[] keys) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(48));
        rp.bottomMargin = dp(4);
        keyboard.addView(row, rp);
        for (String key : keys) {
            TextView b = new TextView(this);
            b.setText(key.equals("␠") ? "Tiếng Dao" : key);
            b.setTextSize(key.length() > 1 ? 13 : 18);
            b.setTypeface(null, Typeface.NORMAL);
            b.setTextColor(Color.rgb(27,39,56));
            b.setGravity(Gravity.CENTER);
            b.setPadding(dp(2), 0, dp(2), 0);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(isSpecial(key) ? Color.rgb(190,207,229) : Color.WHITE);
            bg.setCornerRadius(dp(6));
            b.setBackground(bg);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, key.equals("␠") ? 3.0f : 1.0f);
            lp.setMargins(dp(2), 0, dp(2), 0);
            row.addView(b, lp);
            b.setOnClickListener(v -> handleKey(key));
        }
    }

    private boolean isSpecial(String k) {
        return k.equals("⇧") || k.equals("⌫") || k.equals("↵") || k.equals("?123") || k.equals("␠") || k.equals("PY");
    }

    private void handleKey(String key) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        switch (key) {
            case "⇧": shifted = !shifted; return;
            case "⌫":
                if (composing.length() > 0) {
                    composing.deleteCharAt(composing.length()-1);
                    updateComposing(ic);
                } else {
                    ic.deleteSurroundingText(1, 0);
                }
                return;
            case "↵":
                commitWord(ic);
                ic.commitText("\n", 1);
                return;
            case "␠":
                commitWord(ic);
                ic.commitText(" ", 1);
                return;
            case "?123":
                // Reserved for a future symbols page; keep input stable in this prototype.
                return;
            case "PY":
                typeSequence("py", ic);
                return;
            default:
                if (key.length() == 1 && Character.isLetter(key.charAt(0))) {
                    char c = shifted ? Character.toUpperCase(key.charAt(0)) : key.charAt(0);
                    shifted = false;
                    typeChar(c, ic);
                } else {
                    commitWord(ic);
                    ic.commitText(key, 1);
                }
        }
    }

    private void typeSequence(String s, InputConnection ic) {
        for (int i=0;i<s.length();i++) typeChar(s.charAt(i), ic);
    }

    private void typeChar(char raw, InputConnection ic) {
        char c = Character.toLowerCase(raw);
        // Telex vowel conversions: transform only the last two typed letters.
        if (c == 'w' || c == 'a' || c == 'e' || c == 'o') {
            int n = composing.length();
            if (n > 0) {
                char last = Character.toLowerCase(composing.charAt(n-1));
                if (c == 'w' && last == 'a') { composing.setCharAt(n-1, 'ă'); updateComposing(ic); return; }
                if (c == 'a' && last == 'a') { composing.setCharAt(n-1, 'â'); updateComposing(ic); return; }
                if (c == 'e' && last == 'e') { composing.setCharAt(n-1, 'ê'); updateComposing(ic); return; }
                if (c == 'o' && last == 'o') { composing.setCharAt(n-1, 'ô'); updateComposing(ic); return; }
                if (c == 'w' && last == 'o') { composing.setCharAt(n-1, 'ơ'); updateComposing(ic); return; }
                if (c == 'w' && last == 'u') { composing.setCharAt(n-1, 'ư'); updateComposing(ic); return; }
            }
        }
        if (c == 'f' || c == 's' || c == 'r' || c == 'x' || c == 'j' || c == 'q' || c == 'v' || c == 'z') {
            if (applyMark(c)) { updateComposing(ic); return; }
        }
        composing.append(raw);
        updateComposing(ic);
    }

    private boolean applyMark(char key) {
        if (composing.length() == 0) return false;
        int start = findLastVowelStart();
        if (start < 0) return false;
        // Apply the tone to the vowel itself, not to any consonants typed after it.
        int end = start + 1;
        while (end < composing.length()) {
            char c = composing.charAt(end);
            if (c == '\u0300' || c == '\u0301' || c == '\u0309' || c == '\u0303' ||
                c == '\u0323' || c == '\u030A' || c == '\u0307') end++;
            else break;
        }
        String vowel = composing.substring(start, end);
        String stripped = vowel.replace("\u0300", "").replace("\u0301", "")
            .replace("\u0309", "").replace("\u0303", "").replace("\u0323", "")
            .replace("\u030A", "").replace("\u0307", "");
        if (key == 'z') {
            composing.replace(start, end, stripped);
            return true;
        }
        String mark;
        switch (key) {
            case 'f': mark = "\u0300"; break; // huyền
            case 's': mark = "\u0301"; break; // sắc
            case 'r': mark = "\u0309"; break; // hỏi
            case 'x': mark = "\u0303"; break; // ngã
            case 'j': mark = "\u0323"; break; // nặng
            case 'q': mark = "\u030A"; break; // thanh riêng: vòng tròn trên
            case 'v': mark = "\u0300\u0307"; break; // thanh riêng: huyền + chấm trên
            default: return false;
        }
        composing.replace(start, end, stripped + mark);
        return true;
    }

    private int findLastVowelStart() {
        for (int i = composing.length()-1; i >= 0; i--) {
            char c = Character.toLowerCase(composing.charAt(i));
            if ("aăâeêioôơuưy".indexOf(c) >= 0) return i;
            if (Character.isLetter(c) && "blkgpđntshmrcdyfvw".indexOf(c) >= 0) continue;
        }
        return -1;
    }

    private void updateComposing(InputConnection ic) {
        ic.setComposingText(composing.toString(), 1);
    }

    private void commitWord(InputConnection ic) {
        if (composing.length() > 0) {
            ic.commitText(Normalizer.normalize(composing.toString(), Normalizer.Form.NFC), 1);
            composing.setLength(0);
        }
    }

    @Override public void onFinishInput() {
        super.onFinishInput();
        composing.setLength(0);
    }

    @Override public void onStartInputView(android.view.inputmethod.EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        composing.setLength(0);
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
