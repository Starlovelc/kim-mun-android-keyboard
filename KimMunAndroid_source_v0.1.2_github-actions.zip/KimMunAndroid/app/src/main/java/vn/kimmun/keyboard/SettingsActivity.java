package vn.kimmun.keyboard;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Toast;

public class SettingsActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(24));
        root.setBackgroundColor(Color.rgb(245,247,250));

        TextView title = new TextView(this);
        title.setText("Bàn phím tiếng Dao Đầu Bằng\nKìm Mùn");
        title.setTextSize(24);
        title.setTextColor(Color.rgb(28,43,62));
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView info = new TextView(this);
        info.setText("\nBộ gõ thử nghiệm theo tài liệu nhóm:\n"
            + "• aw → ă, aa → â, ee → ê, oo → ô, ow → ơ, uw → ư\n"
            + "• f/s/r/x/j: huyền/sắc/hỏi/ngã/nặng\n"
            + "• q: vòng tròn trên; v: huyền + chấm trên\n"
            + "• z: xóa dấu thanh\n"
            + "• Phụ âm ghép bl, by, kl, ky, gy, gl, pl, py, đy, th, tk được nhập liên tiếp.\n\n"
            + "Đây là bản thử nghiệm; cần kiểm tra cách gõ và ký tự hiển thị trên thiết bị thực tế.");
        info.setTextSize(16);
        info.setTextColor(Color.DKGRAY);
        root.addView(info, new LinearLayout.LayoutParams(-1, -2));

        Button enable = new Button(this);
        enable.setText("1. Bật bàn phím Kìm Mùn");
        enable.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        root.addView(enable, params());

        Button choose = new Button(this);
        choose.setText("2. Chọn bàn phím Kìm Mùn");
        choose.setOnClickListener(v -> {
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.showInputMethodPicker();
        });
        root.addView(choose, params());

        setContentView(root);
    }
    private LinearLayout.LayoutParams params() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(12);
        return p;
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
